Para executar a nossa solu��o:

> Set working directory

> consult('ficheiro.pl').

> carpooling(Participants, CanDrive, WillDrive).

Exemplo:carpooling([[1,[2,3],[4]],[2,[5,6],[3]],[3,[1],[]],[4,[3,2],[]],[5,[6,7],[]],[6,[3],[]],[7,[2],[]]],[2,3],[7]).                                                    
